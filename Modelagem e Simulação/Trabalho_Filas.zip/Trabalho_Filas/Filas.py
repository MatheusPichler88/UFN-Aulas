
import Calculadora_EarlingC as calc

"""Definindo as funções para calculos das métricas M/M/c baseadas em Erlang C"""
import Calculadora_EarlingC as calc

def utilizacao(a, c):
    return a / c

def tempo_espera_fila(P_wait, c, mu, lam):
    return P_wait / (c * mu - lam)

def num_medio_fila(lam, Wq):
    return lam * Wq

def tempo_medio_sistema(Wq, mu):
    return Wq + 1 / mu

def num_medio_sistema(lam, W):
    return lam * W

def calcular_metricas_mmc(a, c, lam=None, mu=None):
    P_wait = calc.erlang_c(a, c)

    """ Calcula as métricas do sistema M/M/c baseado no tráfego oferecido a=λ/μ (Erlangs) e c servidores.
        Se λ e μ forem fornecidos, calcula todas as métricas; caso contrário, retorna apenas P(wait)."""
    if a >= c:
        return {
            'P_wait': 1.0,
            'utilizacao': a/c,
            'Wq': float('inf'),
            'Lq': float('inf'),
            'W': float('inf'),
            'L': float('inf'),
            'estavel': False
        }
    
    if lam is None or mu is None:
        return {
            'P_wait': P_wait,
            'utilizacao': utilizacao(a, c),
            'Wq': None,
            'Lq': None,
            'W': None,
            'L': None,
            'estavel': True
        }
    
    rho = utilizacao(a, c)
    Wq = tempo_espera_fila(P_wait, c, mu, lam)
    Lq = num_medio_fila(lam, Wq)
    W = tempo_medio_sistema(Wq, mu)
    L = num_medio_sistema(lam, W)
    
    return {
        'P_wait': P_wait,
        'utilizacao': rho,
        'Wq': Wq,
        'Lq': Lq,
        'W': W,
        'L': L,
        'estavel': True
    }

def main():
    print('\n=== Calculadora Erlang C e métricas M/M/c ===')
    print('1) Entrar com a = λ/μ (Erlangs) e c')
    print('2) Entrar com λ, μ e c')
    
    opc = input('Escolha (1/2): ').strip()
    
    lam = None
    mu = None
    
    if opc == '1':
        a = calc.ler_float('Informe a (λ/μ) em Erlangs: ')
        c = calc.ler_int('Informe c (nº de servidores): ')
        
    elif opc == '2':
        lam = calc.ler_float('Informe λ (taxa de chegadas): ')
        mu = calc.ler_float('Informe μ (taxa de atendimento por servidor): ')
        c = calc.ler_int('Informe c (nº de servidores): ')
        
        if mu <= 0:
            print('Erro: μ deve ser maior que 0.')
            return
            
        a = lam / mu
        print(f'\na = λ/μ = {a:.6f} Erlangs')
        
    else:
        print('Opção inválida!')
        return
    
    metricas = calcular_metricas_mmc(a, c, lam, mu)
    
    print('\n' + '='*50)
    print('RESULTADOS M/M/c')
    print('='*50)
    
    print(f'Número de servidores (c): {c}')
    print(f'Tráfego oferecido (a): {a:.6f} Erlangs')
    
    if not metricas['estavel']:
        print('\n*** SISTEMA INSTÁVEL ***')
        print(f'P(wait): {metricas["P_wait"]:.6f} (100.00%)')
        print(f'Utilização (ρ): {metricas["utilizacao"]:.6f} ({metricas["utilizacao"]*100:.2f}%)')
        print('Wq (tempo médio na fila): ∞')
        print('Lq (número médio na fila): ∞')
        print('W (tempo médio no sistema): ∞')
        print('L (número médio no sistema): ∞')
    else:
        print(f'\nP(wait): {metricas["P_wait"]:.6f} ({metricas["P_wait"]*100:.2f}%)')
        print(f'Utilização (ρ): {metricas["utilizacao"]:.6f} ({metricas["utilizacao"]*100:.2f}%)')
        
        if lam is not None and mu is not None:
            print(f'Wq (tempo médio na fila): {metricas["Wq"]:.6f}')
            print(f'Lq (número médio na fila): {metricas["Lq"]:.6f}')
            print(f'W (tempo médio no sistema): {metricas["W"]:.6f}')
            print(f'L (número médio no sistema): {metricas["L"]:.6f}')

if __name__ == '__main__':
    while True:
        main()
        denovo = input('\nDeseja calcular novamente? (s/n): ').strip().lower()
        if denovo != 's':
            print('Encerrado.')
            break
