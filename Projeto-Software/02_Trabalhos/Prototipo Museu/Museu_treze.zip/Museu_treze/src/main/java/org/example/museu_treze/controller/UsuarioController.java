package org.example.museu_treze.controller;

import org.example.museu_treze.model.Usuario;
import org.example.museu_treze.repository.UsuarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioRepository repository;

    @GetMapping("/cadastro")
    public String abrirTela(Model model) {

        model.addAttribute("usuario", new Usuario());

        return "cadastro";
    }

    @PostMapping("/salvar")
    public String salvar(Usuario usuario, Model model) {

        repository.salvar(usuario);

        model.addAttribute("mensagem", "Usuário cadastrado com sucesso!");

        return "cadastro";
    }
}