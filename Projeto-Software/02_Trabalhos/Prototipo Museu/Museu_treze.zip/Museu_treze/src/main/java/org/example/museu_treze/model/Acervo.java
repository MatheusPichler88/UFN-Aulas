package org.example.museu_treze.model;

public class Acervo {
    private String titulo;
    private String autor;
    private String categoria;
    private String status;
    private String codigo;
    public Acervo(){
    }
    public Acervo(String titulo, String autor, String categoria, String statud, String codigo){
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.status = status;
        this.codigo = codigo;

    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
