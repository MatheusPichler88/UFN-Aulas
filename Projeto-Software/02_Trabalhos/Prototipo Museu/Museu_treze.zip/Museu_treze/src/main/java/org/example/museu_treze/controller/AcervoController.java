package org.example.museu_treze.controller;

import org.example.museu_treze.model.Acervo;
import org.example.museu_treze.repository.AcervoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
@Controller
public class AcervoController {

    @Autowired
    private AcervoRepository repository;

    @GetMapping("/acervo")
    public String abrirTela(Model model){
        model.addAttribute("acervo", new Acervo());
    return "acervo";
    }

    @PostMapping("/salvarAcervo")
    public String salvarAcervo(Acervo acervo, Model model){
        repository.salvar(acervo);
        model.addAttribute("mensagem", "Item cadastrado no acervo");
        return "acervo";
    }
}
