package org.example.museu_treze.repository;

import org.example.museu_treze.model.Acervo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class AcervoRepository {

    private List<Acervo> listaAcervo = new ArrayList<>();

    public void salvar(Acervo acervo){

        listaAcervo.add(acervo);

    }

    public List<Acervo> listar(){

        return listaAcervo;

    }
}