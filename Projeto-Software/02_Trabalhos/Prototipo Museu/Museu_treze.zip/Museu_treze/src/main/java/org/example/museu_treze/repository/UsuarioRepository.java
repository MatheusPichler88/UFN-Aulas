package org.example.museu_treze.repository;

import org.example.museu_treze.model.Usuario;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class UsuarioRepository {

    private List<Usuario> listaUsuario = new ArrayList<>();

    public void salvar(Usuario usuario){

        listaUsuario.add(usuario);

    }

    public List<Usuario> listar(){

        return listaUsuario;

    }
}