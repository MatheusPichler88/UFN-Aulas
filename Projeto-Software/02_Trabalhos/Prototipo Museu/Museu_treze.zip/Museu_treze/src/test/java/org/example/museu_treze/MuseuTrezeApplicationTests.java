package org.example.museu_treze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuseuTrezeApplicationTests {

    @Test
    void contextLoads() {
    }

}
